# from collections import deque
# def next_greater(heights):
#     while
