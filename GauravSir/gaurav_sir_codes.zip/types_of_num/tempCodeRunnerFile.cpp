if(checkfac(A)){
            cout<<n<<" ";
        }