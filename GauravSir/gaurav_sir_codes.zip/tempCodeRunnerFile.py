def allNegative(n,arr):
#     for i in range(n): 
#         if arr[i]>0: 
#             return False
#     return True

# n=int(input())
# arr=list(map(int,input().split()))
# x=allNegative(n,arr)
# print(x)